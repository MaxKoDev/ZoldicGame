from tkinter import *
from PIL import Image
from tkinter import messagebox
from random import randint

import pygame

pygame.mixer.init()

musique_map1 = "menu1.mp3"
musique_map2 = "menu2.mp3"

message_affiche = False
tir_en_cours = False
timer_tir = None
transition_en_cours = False  # gérer la transition
map_actuelle = 1


def jouer_musique(musique):
    pygame.mixer.music.stop()
    pygame.mixer.music.load(musique)
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)  # -1 pour jouer en boucle

jouer_musique(musique_map1)

def traitementObjet1():
    global Objet1, personnage, message_affiche
    if Objet1:
        coords = ca.coords(Objet1)
        if coords:  # Vérifier que l'objet a encore des coordonnées
            xObjet, yObjet = coords
            xPerso, yPerso = ca.coords(personnage)

            if (xObjet - 40 < xPerso < xObjet + 40) and (yObjet - 40 < yPerso < yObjet + 40):
                if inventaire["Objet1"] == "Transformé":
                    messagebox.showinfo("Victoire", "Vous avez ramassé la pierre précieuse et gagné le jeu !\nMais attention... Ce n'est que le commencement.")
                    ca.delete(Objet1)
                    Objet1 = None  # Supprimer l'objet de la mémoire
                elif inventaire["Objet2"] != "Trouvé":
                    if not message_affiche:
                        messagebox.showinfo("Attention", "Vous ne pouvez pas traverser cet objet sans avoir trouvé l'Objet2 !")
                        message_affiche = True  
                    ca.coords(personnage, xPerso - 10, yPerso)  # Reculer le joueur de 10 pixels vers la gauche
                else:
                    ca.delete(Objet1)
                    Objet1 = ca.create_image(xObjet, yObjet, image=imageObjetTransforme)
                    inventaire["Objet1"] = "Transformé"
                    updateInventaire()
                    messagebox.showinfo("Succès", "Vous pouvez maintenant réunir vos forces")
        else:
            Objet1 = None  # Éviter d'accéder à un objet supprimé
    else:
        message_affiche = False  # Réinitialisation du message

def traitementObjet2():
    global Objet2, personnage
    if Objet2:
        xPerso, yPerso = ca.coords(personnage)
        xObjet, yObjet = ca.coords(Objet2)
        if xObjet - 20 < xPerso < xObjet + 20 and yObjet - 20 < yPerso < yObjet + 20:
            ca.delete(Objet2)
            messagebox.showinfo("Félicitations", "Vous avez trouvé l'arme, Vous pouvez maintenant tirer en appuyant sur la touche W")
            Objet2 = None
            inventaire["Objet2"] = "Trouvé"
            updateInventaire()
            ca.delete(zone_interdite)

def deplacerObjet2():
    global Objet2
    if Objet2:
        xObjet, yObjet = ca.coords(Objet2)
        
        # Générer un déplacement aléatoire
        dx, dy = randint(-200, 200), randint(-200, 200)
        xNouveau, yNouveau = xObjet + dx, yObjet + dy
        
        # Vérifier les limites de la carte
        if xNouveau < 50:
            xNouveau = 50
        if xNouveau > 1750:
            xNouveau = 1750
        if yNouveau < 50:
            yNouveau = 50
        if yNouveau > 988:
            yNouveau = 988
        
        # Appliquer le nouveau positionnement
        ca.coords(Objet2, xNouveau, yNouveau)
    
    fenetre.after(5000, deplacerObjet2)


def deplacerMonstre(): #Meme code que pour deplacerObjet2, on remplace juste la variable Objet2 par Monstre
    global Monstre
    if Monstre:
        xMonstre, yMonstre = ca.coords(Monstre)
        
        dx, dy = randint(-200, 200), randint(-200, 200)
        xNouveau, yNouveau = xMonstre + dx, yMonstre + dy
        
        if xNouveau < 50:
            xNouveau = 50
        if xNouveau > 1750:
            xNouveau = 1750
        if yNouveau < 50:
            yNouveau = 50
        if yNouveau > 988:
            yNouveau = 988
        
        ca.coords(Monstre, xNouveau, yNouveau)
    
    fenetre.after(5000, deplacerMonstre)

def traitementMonstre():
    global Monstre, personnage
    if Monstre:
        xPerso, yPerso = ca.coords(personnage)
        xMonstre, yMonstre = ca.coords(Monstre)
        if xMonstre - 20 < xPerso < xMonstre + 20 and yMonstre - 20 < yPerso < yMonstre + 20:
            ca.delete(Monstre)
            messagebox.showinfo("Félicitations", "Vous avez tué le monstre")
            Monstre = None

def deplacer_tir():
    global Tir, tir_en_cours, Objet1
    if Tir:
        xTir, yTir = ca.coords(Tir)
        xObjet, yObjet = ca.coords(Objet1)
        
        # Vérifier si le tir touche l'objet 1
        if Objet1 and (xObjet - 40 < xTir < xObjet + 40) and (yObjet - 40 < yTir < yObjet + 40):
            if inventaire["Objet2"] != "Trouvé":
                messagebox.showinfo("Attention", "Une force magnétique empêche le tir de passer !")
            else:
                ca.delete(Objet1)
                Objet1 = ca.create_image(xObjet, yObjet, image=imageObjetTransforme)
                inventaire["Objet1"] = "Transformé"
                updateInventaire()
                messagebox.showinfo("Succès", "Votre force a permis à la pierre de se transformer !")
            
            ca.delete(Tir)
            Tir = None
            tir_en_cours = False
            return
        
        # Tir
        if yTir < 1028:
            ca.move(Tir, 0, 10)
            fenetre.after(10, deplacer_tir)
        else:
            ca.delete(Tir)
            Tir = None
            tir_en_cours = False


def move(event):
    global personnage, Tir, cpt, direction, tir_en_cours
    touche = event.char
    xPerso, yPerso = ca.coords(personnage)
    cpt = (cpt + 1) % 5  # Cycle à travers les sprites

    # Mise a jour du sprite
    if touche == 'z':  #Si la touche Z est préssée, alors on bouge le personnage en haut
        direction = "haut"
        if yPerso > 30:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso, yPerso - 10, image=LSprite[2][cpt])
    elif touche == 's':  #Si la touche S est préssée, alors on bouge le personnage en bas
        direction = "bas"
        if yPerso < 1028:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso, yPerso + 10, image=LSprite[3][cpt])
    elif touche == 'q':  #Si la touche Q est préssée, alors on bouge le personnage vers la gauche
        direction = "gauche"
        if xPerso > 10:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso - 10, yPerso, image=LSprite[0][cpt])
    elif touche == 'd':  #Si la touche D est préssée, alors on bouge le personnage vers la droite
        direction = "droite"
        if xPerso < 1790:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso + 10, yPerso, image=LSprite[1][cpt])
    
    if touche == 'w' and not tir_en_cours and inventaire["Objet2"] == "Trouvé":
        tir_en_cours = True
        Tir = ca.create_image(xPerso, yPerso, image=imageTir)
        deplacer_tir()

    traitementObjet1()
    traitementObjet2()

    changer_de_map()

def updateInventaire():
    invText.set(f"Inventaire:\nPierre Mysterieuse: {inventaire['Objet1']}\nArme: {inventaire['Objet2']}")

def fermerApplication(event): #fermer la fenetre si le clique souris est actif
    fenetre.quit()


fenetre = Tk()
fenetre.geometry("1800x1038")
fenetre.bind("<Button-1>", fermerApplication)
fenetre.bind("<Any-KeyPress>", move)

imageMap = PhotoImage(file="map.png")
imageObjet1 = PhotoImage(file="objet1.png")
imageObjetTransforme = PhotoImage(file="objet1_transforme.png")
imageObjet2 = PhotoImage(file="gun.png")
imagePortail = PhotoImage(file="portail.png")
imageTir = PhotoImage(file="coin.png")
ImageMonstre = PhotoImage(file="ennemi.png")


img = Image.open("sprite.png")
LSprite = []
for i in range(4):  #gestion du sprite
    LTemp = []
    for j in range(5):  # 5 frames par direction
        x, y = 90 * j, 90 * i
        img2 = img.crop([x, y, x + 90, y + 90])
        img2.save("temp.png")
        imageTemp = PhotoImage(file="temp.png")
        LTemp.append(imageTemp)
    LSprite.append(LTemp)

ca = Canvas(width=1800, height=1038)
ca.place(x=0, y=0)
ca.create_image(900, 519, image=imageMap)

def position_aleatoire():
    x = randint(100, 1700)
    y = randint(100, 950)
    return x, y

# Génération des positions aléatoires au début du jeu
xPerso, yPerso = position_aleatoire()
xObjet1, yObjet1 = position_aleatoire()
xObjet2, yObjet2 = position_aleatoire()
xPortail, yPortail = position_aleatoire()
xMonstre, yMonstre = position_aleatoire()

Objet1 = ca.create_image(xObjet1, yObjet1, image=imageObjet1)
Objet2 = ca.create_image(xObjet2, yObjet2, image=imageObjet2)
personnage = ca.create_image(xPerso, yPerso, image=LSprite[2][2])
portail = ca.create_image(xPortail, yPortail, image=imagePortail)
Monstre = ca.create_image(xMonstre, yMonstre, image=ImageMonstre)

# Création de la hitbox
zone_interdite = ca.create_rectangle(
    xObjet1 - 40, yObjet1 - 40, xObjet1 + 40, yObjet1 + 40, outline="white", width=3
)

#CODE POUR CHANGER DE MAP
def changer_de_map():
    global personnage, ca, portail, transition_en_cours, map_actuelle

    if portail is None:
        return

    coords = ca.coords(portail)
    if coords is None or len(coords) < 2:
        return

    xPortail, yPortail = coords
    xPerso, yPerso = ca.coords(personnage)

    if xPortail - 40 < xPerso < xPortail + 40 and yPortail - 40 < yPerso < yPortail + 40:
        if transition_en_cours:
            return

        transition_en_cours = True
        map_actuelle = 2 if map_actuelle == 1 else 1  # Changer entre map1 et map2
        ca.create_rectangle(0, 0, 1800, 1038, fill="black", outline="black")

        if map_actuelle == 1:
            jouer_musique(musique_map1)
        else:
            jouer_musique(musique_map2)
            
        fenetre.after(2000, charger_nouvelle_map)

#CHARGER LA NOUVELLE MAP
def charger_nouvelle_map():
    global personnage, Objet1, Objet2, portail, transition_en_cours, ca, imageMap, imageMap2, map_actuelle

    ca.delete("all")

    if map_actuelle == 1:
        imageMap = PhotoImage(file="map.png")
        ca.create_image(900, 519, image=imageMap)
    else:
        imageMap2 = PhotoImage(file="map2.png")
        ca.create_image(900, 519, image=imageMap2)

    xPerso, yPerso = position_aleatoire()
    xObjet1, yObjet1 = position_aleatoire()
    xObjet2, yObjet2 = position_aleatoire()
    xPortail, yPortail = position_aleatoire()
    xMonstre, yMonstre = position_aleatoire()

    Objet1 = ca.create_image(xObjet1, yObjet1, image=imageObjet1)
    Objet2 = ca.create_image(xObjet2, yObjet2, image=imageObjet2)
    personnage = ca.create_image(xPerso, yPerso, image=LSprite[2][2])
    portail = ca.create_image(xPortail, yPortail, image=imagePortail)
    Monstre = ca.create_image(xMonstre, yMonstre, image=ImageMonstre)

    zone_interdite = ca.create_rectangle(
    xObjet1 - 40, yObjet1 - 40, xObjet1 + 40, yObjet1 + 40, outline="red", width=3
)

    transition_en_cours = False


cpt = 0
invText = StringVar()
inventaire = {"Objet1": "Non touché", "Objet2": "Non trouvé"}
updateInventaire()
Label(fenetre, textvariable=invText, font=("Georgia", 14), fg="white", bg="brown").pack(side=RIGHT) #On écrit l'inventaire dans une nouvelle fenetre avec la police "Georgia"

# Déplacer l'objet 2
deplacerObjet2()

# Déplacer le monstre
deplacerMonstre()

fenetre.mainloop()
