from tkinter import *
from random import randint

transition_en_cours = False

# Fonction de gestion de la transition
def transition_vers_nouvelle_map():
    global transition_en_cours
    if transition_en_cours:
        return

    transition_en_cours = True
    ca.create_rectangle(0, 0, 1800, 1038, fill="black", outline="black")  # Créer un écran noir
    fenetre.after(2000, charger_nouvelle_map)  # Attendre 2 secondes avant de charger la nouvelle carte

# Charger la nouvelle carte après la transition
def charger_nouvelle_map():
    global personnage, Objet1, Objet2, portail
    # Effacer l'ancienne carte
    ca.delete("all")

    # Recréer la nouvelle carte
    imageMap2 = PhotoImage(file="new_map.png")  # Nouvelle image de carte
    ca.create_image(900, 519, image=imageMap2)  # Placer la nouvelle carte

    # Positionner les objets et le personnage sur la nouvelle carte
    xPerso, yPerso = position_aleatoire()
    xObjet1, yObjet1 = position_aleatoire()
    xObjet2, yObjet2 = position_aleatoire()

    Objet1 = ca.create_image(xObjet1, yObjet1, image=imageObjet1)
    Objet2 = ca.create_image(xObjet2, yObjet2, image=imageObjet2)
    personnage = ca.create_image(xPerso, yPerso, image=LSprite[2][2])

    # Recréer le portail à une position aléatoire
    xPortail, yPortail = position_aleatoire()
    portail = ca.create_image(xPortail, yPortail, image=imagePortail)

    # Recréer la hitbox de l'objet
    zone_interdite = ca.create_rectangle(
        xObjet1 - 40, yObjet1 - 40, xObjet1 + 40, yObjet1 + 40, outline="red", width=3
    )

    transition_en_cours = False  # Fin de la transition

# Positionner les éléments à des positions aléatoires
def position_aleatoire():
    x = randint(100, 1700)
    y = randint(100, 950)
    return x, y

# Fonction pour gérer le mouvement du joueur
def move(event):
    global personnage, Tir, cpt, direction, tir_en_cours
    touche = event.char
    xPerso, yPerso = ca.coords(personnage)
    cpt = (cpt + 1) % 5  # Cycle à travers les sprites

    # Mise à jour du sprite
    if touche == 'z':  # Si la touche Z est pressée, on bouge le personnage en haut
        direction = "haut"
        if yPerso > 30:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso, yPerso - 10, image=LSprite[2][cpt])
    elif touche == 's':  # Si la touche S est pressée, on bouge le personnage en bas
        direction = "bas"
        if yPerso < 1028:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso, yPerso + 10, image=LSprite[3][cpt])
    elif touche == 'q':  # Si la touche Q est pressée, on bouge le personnage vers la gauche
        direction = "gauche"
        if xPerso > 10:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso - 10, yPerso, image=LSprite[0][cpt])
    elif touche == 'd':  # Si la touche D est pressée, on bouge le personnage vers la droite
        direction = "droite"
        if xPerso < 1790:
            ca.delete(personnage)
            personnage = ca.create_image(xPerso + 10, yPerso, image=LSprite[1][cpt])

    # Vérifier si le joueur touche le portail pour déclencher la transition
    if touche == 'e':
        xPortail, yPortail = ca.coords(portail)
        if xPortail - 40 < xPerso < xPortail + 40 and yPortail - 40 < yPerso < yPortail + 40:
            transition_vers_nouvelle_map()

# Création de la fenêtre
fenetre = Tk()
fenetre.geometry("1800x1038")
fenetre.bind("<Button-1>", fermerApplication)
fenetre.bind("<Any-KeyPress>", move)

# Chargement des images
imageMap = PhotoImage(file="map.png")
imagePortail = PhotoImage(file="portail.png")  # Image du portail
imageObjet1 = PhotoImage(file="objet1.png")
imageObjetTransforme = PhotoImage(file="objet1_transforme.png")
imageObjet2 = PhotoImage(file="gun.png")
imageTir = PhotoImage(file="coin.png")

# Chargement des sprites
img = Image.open("sprite.png")
LSprite = []
for i in range(4):  # 4 directions / Mise à jour du sprite et gestion du sprite
    LTemp = []
    for j in range(5):  # 5 frames par direction
        x, y = 90 * j, 90 * i
        img2 = img.crop([x, y, x + 90, y + 90])
        img2.save("temp.png")
        imageTemp = PhotoImage(file="temp.png")
        LTemp.append(imageTemp)
    LSprite.append(LTemp)

# Création du canvas pour afficher les éléments
ca = Canvas(width=1800, height=1038)
ca.place(x=0, y=0)
ca.create_image(900, 519, image=imageMap)

# Positionner les éléments sur la carte
xPerso, yPerso = position_aleatoire()
xObjet1, yObjet1 = position_aleatoire()
xObjet2, yObjet2 = position_aleatoire()

Objet1 = ca.create_image(xObjet1, yObjet1, image=imageObjet1)
Objet2 = ca.create_image(xObjet2, yObjet2, image=imageObjet2)
personnage = ca.create_image(xPerso, yPerso, image=LSprite[2][2])

# Création du portail
xPortail, yPortail = position_aleatoire()
portail = ca.create_image(xPortail, yPortail, image=imagePortail)

# Création de la hitbox pour l'objet
zone_interdite = ca.create_rectangle(
    xObjet1 - 40, yObjet1 - 40, xObjet1 + 40, yObjet1 + 40, outline="red", width=3
)

cpt = 0
invText = StringVar()
inventaire = {"Objet1": "Non touché", "Objet2": "Non trouvé"}
updateInventaire()
Label(fenetre, textvariable=invText, font=("Georgia", 14), fg="white", bg="brown").pack(side=RIGHT)

fenetre.mainloop()
